 <? front_header() ?>
  
  <!-- [/MAIN-HEADING]
 ============================================================================================================================-->
  <section class="main-heading" id="home">
 <div class="baner"> <img src="<? echo base_url('assets/') ?>images/inbanner.jpg" class="img-responsive" />
	  </div> 
	  
	  
	  
	  
	
  </section>
  
  <!-- [/MAIN-HEADING]
 ============================================================================================================================--> 
  
  <!-- [ABOUT US]
 ============================================================================================================================-->
  <section class="white-background black" id="inpage">
    <div class="container">
      <div class="row">
        <div class="col-md-12  black">
          <h3 class="title"> Cancellation & Return Policy </h3>
         
		<ul>		
       <li>It is advised to all visitors to kindly view the following policy before filling up the registration form. The Institute for Academic Excellence would not take any responsibility if the applicant fails to understand the mentioned clauses.</li>
<li>Registration fees is non refundable in any circumstances once it is successfully paid.</li>
<li>	Registration fees cannot be transferred to any other participants.</li>

</ul>
			<h2>General Rules:</h2>
			<ul>
			<li>Tea/Snacks/Lunch will be provided on two days for all registered candidates</li>
<li>	Arrangements have to be made for accommodation by the delegates only.</li>
<li>	Organizers have the right to alter date, time and venue of the workshop.</li>
<li>	Participants are informed to carry identity cards.  </li>
</ul>

			<br/>


        </div>
      </div>
      <div class="gap"> </div>
      
      <!-- /row --> 
      
    </div>
  </section>
  
 <? front_footer() ?>