<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ripf extends CI_Controller {

	public function __construct(){
		
		parent::__construct();
		if(!$this->session->userdata['adminid'])
            {
                redirect('admin');
            }
	}

	public function index()
	{	
		$data["rcategories"] = $this->db->order_by("id","desc")->get_where("tbl_ripf_categories",["deleted"=>0])->result();
		$data["rtopics"] = $this->db->order_by("id","desc")->get_where("tbl_ripf_topics",["deleted"=>0])->result();
		$this->load->view("admin/ripf/ripf",$data);
	}
	
	public function insertCategory(){
		
		$category_name = $this->input->post("category_name");
		$overall_discount_amount = $this->input->post("overall_discount_amount");
		$members_count = $this->input->post("members_count");
		$sid = $this->input->post("id");
		
		if($sid){
			$mochk = $this->db->get_where("tbl_ripf_categories",array("category_name"=>$category_name,"id !="=>$sid))->num_rows();
		}else{
			$mochk = $this->db->get_where("tbl_ripf_categories",array("category_name"=>$category_name))->num_rows();
		}
		
		if($mochk >= 1){
			$this->secure->pnotify("error","Already exists.","error");
			redirect("admin/ripf");
		}
		
		$idata = array(
			"category_name" => $category_name,
			"overall_discount_amount" => $overall_discount_amount,
			"members_count" => $members_count
		);
		
		if($sid){
			$id = $this->db->where("id",$sid)->update("tbl_ripf_categories",$idata);
		}else{
			$id = $this->db->insert("tbl_ripf_categories",$idata);	
		}
		
		if($id){
			$status = ($sid) ? "Updated" : "Added";
			$this->secure->pnotify("success","Successfully $status.","Success");
			redirect("admin/ripf");
		}else{
			$this->secure->pnotify("error","Error occured","error");
			redirect("admin/ripf");
		}
		
	}
	
	public function delCategory($id){
		
		$d = $this->db->where(array("id"=>$id))->update("tbl_ripf_categories",array("deleted"=>1));
		
		if($d){
			
			$this->secure->pnotify("success","Successfully deleted.","Success");
			redirect("admin/ripf");
			
		}else{
			
			$this->secure->pnotify("error","Error occured","error");
			redirect("admin/ripf");
			
		}
		
	}
	
	public function insertTopic(){
		
		$ripf_category = $this->input->post("ripf_category");
		$topic_name = $this->input->post("topic_name");
		$amount = $this->input->post("amount");
		$sid = $this->input->post("id");
		
		$idata = array(
			"ripf_category" => $ripf_category,
			"topic_name" => $topic_name,
			"amount" => $amount
		);
		
		if($sid){
			$id = $this->db->where("id",$sid)->update("tbl_ripf_topics",$idata);
		}else{
			$id = $this->db->insert("tbl_ripf_topics",$idata);	
		}
		
		if($id){
			$status = ($sid) ? "Updated" : "Added";
			$this->secure->pnotify("success","Successfully $status.","Success");
			redirect("admin/ripf");
		}else{
			$this->secure->pnotify("error","Error occured","error");
			redirect("admin/ripf");
		}
		
	}
	
	public function delTopic($id){
		
		$d = $this->db->where(array("id"=>$id))->update("tbl_ripf_categories",array("deleted"=>1));
		
		if($d){
			
			$this->secure->pnotify("success","Successfully deleted.","Success");
			redirect("admin/ripf");
			
		}else{
			
			$this->secure->pnotify("error","Error occured","error");
			redirect("admin/ripf");
			
		}
		
	}
		
}
