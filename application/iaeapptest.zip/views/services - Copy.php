<? front_header() ?>
  
  <!-- [/MAIN-HEADING]
 ============================================================================================================================-->
  <section class="main-heading" id="home">
 <div class="baner"> <img src="<? echo base_url('assets/') ?>images/inbanner.jpg" class="img-responsive" />
	  </div> 
	  
	  
	  
	  
	
  </section>
  
  <!-- [/MAIN-HEADING]
 ============================================================================================================================--> 
  
  <!-- [ABOUT US]
 ============================================================================================================================-->
  <section class="white-background black" id="inpage">
    <div class="container">
      <div class="row">
        <div class="col-md-12  black">
          	
           <h3 class="title"> Services Offered:  </h3>
			  <p>
			  		We provide services to Higher Educational Institutions to help them to raise their
					profiles on a global scale and become top performers in their field. <br>
					
        			We provide meaningful and actionable inputs, to refine the strategies and to apply
					course corrections and to prepare “Roadmap” to further enhance Ranking
					position, Recognition, Accreditation and Grading process.	
         
         	  </p>
          
          <br>
          
          	<h3><strong>1) NBA, NAAC, NIRF Support</strong></h3>
          
			<ul style="margin-left: 20px">

				<li>Preparation of SAR, SSR Reports</li>
				<li>Assessment and Data Analysis</li>
				<li>Collaboration for organizing Workshops</li>

			</ul>
			
			<br/>
			
			<h3><strong>2) Academic & Administrative Audit</strong></h3>
          
			<ul style="margin-left: 20px">

				<li>Institution SWOC Analysis</li>
				<li>Best Practices implementation Strategies</li>
				<li>Continues Assessment and Evaluation</li>

			</ul>
			
			<br/>

        	<h3><strong>3) Assessment & Enhancement</strong></h3>
          
			<ul style="margin-left: 20px">

				<li>Faculty Performance</li>
				<li>Teaching-Learning and Evaluation</li>
				<li>Research and Professional Practice</li>
				<li>Graduate Outcomes</li>
				<li>Student Enrollment</li>

			</ul>
			
			<br/>
        
        	<h3><strong>Key Differentiators</strong></h3>
          
			<ul style="margin-left: 15px">

				<li style="list-style: none">1) Team of Academic experts, experience in different audit processes</li>
				<li style="list-style: none">2) Ability to hand hold in implementing the Best Practices recommended in the chosen areas</li>
				<li style="list-style: none">3) Rich question bank drawn from past experience and best frameworks for review purposes</li>
				<li style="list-style: none">4) Professionals with the past experience in managing the program engagement of Internal Quality System, Assessments and Accreditations</li>
				<li style="list-style: none">5) Leveraging the existing quality Assets of the institute</li>

			</ul>
			
			<br/>

        </div>
      </div>
      <div class="gap"> </div>
      
      <!-- /row --> 
      
    </div>
  </section>
  
 <? front_footer() ?>