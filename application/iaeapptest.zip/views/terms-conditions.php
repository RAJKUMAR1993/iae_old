<? front_header() ?>
  
  <!-- [/MAIN-HEADING]
 ============================================================================================================================-->
  <section class="main-heading" id="home">
 <div class="baner"> <img src="<? echo base_url('assets/') ?>images/inbanner.jpg" class="img-responsive" />
	  </div> 
	  
	  
	  
	  
	
  </section>
  
  <!-- [/MAIN-HEADING]
 ============================================================================================================================--> 
  
  <!-- [ABOUT US]
 ============================================================================================================================-->
  <section class="white-background black" id="inpage">
    <div class="container">
      <div class="row">
        <div class="col-md-12  black">
          <h3 class="title"> Terms & Conditions  </h3>
         
				
          <p>All the terms and conditions must be read very carefully. If you use the website(s) it clearly implies that you agree to abide by all the terms and conditions prescribed by the Institute for Academic Excellence. By using the website(s), you accept that this will form a legal binding agreement between you and Institute for Academic Excellence.  </p>
			<ul>
		<li>All information displayed on the www.iae.education and other website(s) maintained by the Institute for Academic Excellence is meant for general information. Visitors may download information available on the website(s) for non-commercial, personal use only and no part of information, either in whole or part, shall be printed, distributed, transmitted, modified, displayed or otherwise reproduced without the prior written permission of Institute for Academic Excellence.</li>
<li>Institute for Academic Excellence reserves the right to make alterations, partly/completely and delete any material/content on the website(s) and all other information including the offers, if any, without notice. No responsibility will be accepted by the Institute for Academic Excellence for damage or loss or any kind of hardships or expense encountered by its visitors or any other person or entities for such changes, additions, deletions, omissions or errors, no matter how they are caused.</li>
<li>Every effort is made to keep the website(s) up and running smoothly. However, the Institute for Academic Excellence takes no responsibility for and will not be liable for the website(s) being temporarily unavailable due to technical issues beyond its control.</li>
<li>Institute for Academic Excellence may share information about the visitors and/or users of its website(s) to communicate with the concerned visitors and/or users or otherwise as deemed necessary.</li>
<li>Use of any information at the website(s) is at one's own risk. While every effort is made to secure our network communications, however, Institute for Academic Excellence may not always be able to ensure the privacy of online communications and other information of the visitors, unless otherwise specifically provided for. Moreover, any information that one provides using this web site(s) may become part of a public record subject to disclosure under the relevant regulations from time to time. </li>
<li>The Disclaimer and Privacy Policy shall be read part and parcel of these Terms & Conditions. </li>
<li>	Institute for Academic Excellence may at any time modify the Terms & Conditions without any prior notification. You can access the latest version of the Terms & Conditions at any given time. You should regularly review the Terms & Conditions.</li>
<li> Visitors of our website(s) hereby agree to indemnify and hold the Institute for Academic Excellence, its management, officers, employees, information providers and other persons or entities associated with the Institute for Academic Excellence harmless for any claims, losses or damages resulting from the breach of these terms or relying upon or use of its web site(s) as well as any links to or from other sites or other resources.</li>
<li>This agreement is governed and construed in accordance with the Laws of Union of India. You hereby irrevocably consent to the exclusive jurisdiction and venue of courts in Hyderabad, Telangana, India in all disputes arising out of or relating to the use of the website(s). </li>
	
			
			
	</ul>
			
			
		
		
			<br/>


        </div>
      </div>
      <div class="gap"> </div>
      
      <!-- /row --> 
      
    </div>
  </section>
  
 <? front_footer() ?>