<? front_header() ?>
  
  <!-- [/MAIN-HEADING]
 ============================================================================================================================-->
  <section class="main-heading" id="home">
 <div class="baner"> <img src="<? echo base_url('assets/') ?>images/inbanner.jpg" class="img-responsive" />
	  </div> 
	  
	  
	  
	  
	
  </section>
  
  <!-- [/MAIN-HEADING]
 ============================================================================================================================--> 
  
  <!-- [ABOUT US]
 ============================================================================================================================-->
  <section class="white-background black" id="inpage">
    <div class="container">
      <div class="row">
        <div class="col-md-12  black">
          <h3 class="title"> About Institute for Academic Excellence (IAE)  </h3>
         
				
          <p>
          		The Institute for Academic Excellence (IAE) is an independent academic service
				provider dedicated in serving the Higher Educational Institutions to achieve
				success through developing Best practices & Bench marking standards in
				curriculum and other related aspects. The IAE promotes / suggests academic
				institutions in developing academic programs, strategies and methods to enhance
				Institution reputation. 
				
				<br>
		
				IAE has roots in the two decade old and renowned KAB consultants, an organisation
				striving for the cause of quality enhancement in the academic arena.	
			
				<br>

	  			IAE endeavours towards the institutional building, adoption of best practices in the
				journey towards academic excellence of the educational institutions with which it
				partners. IAE bench marks with the world best standards in Academic &
				Administrative areas and makes recommendations along with a clearly spelt road
				map to accomplish the same. IAE operates through a strong resource base and
				pool of best brains in each of the areas of operation.
				
				<br>

		  </p>
				
			<br/>

        
          <h3><strong>Vision:</strong></h3><br>
	
          
          	<p style="margin-left: 20px">
          		
          		To be the world class service provider for creation, transmission, use and
				dissemination of knowledge for holistic development of the students and
				faculty. It enhances the Academic Excellence for overall development
				of the Institutions and to derive stakeholder satisfaction.
          		
          	</p>
          <br>
		
          <h3><strong>Values:</strong></h3>	
          
          	<ul style="margin-left: 20px">
          		
          		<li>Professional Ethics</li>
          		<li>Integrity</li>
          		<li>Confidentiality</li>
          		<li>Transparency</li>
          		
          	</ul>	

        </div>
      </div>
      <div class="gap"> </div>
      
      <!-- /row --> 
      
    </div>
  </section>
  
 <? front_footer() ?>